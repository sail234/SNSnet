"""for special loss function"""
