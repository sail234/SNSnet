import tensorflow as tf
import rtp_fg
import json
from fg_worker import FeatureColumnGenerator

table_col_num = 4
fg_file_path = './ziya_fliggy_supergul_dnn.json'
fg_tf_file_path = './ziya_fliggy_supergul_dnn_tf.json'


def parse_fg(data_batch, FLAGS):
    tf.logging.info("loading json config...")
    with open(fg_file_path, 'r') as f:
        feature_configs_java = json.load(f)
    with open(fg_tf_file_path, 'r') as f:
        feature_configs_tf = json.load(f)

    tf.logging.info("java fg parsing...")
    features, label_dict = parser(data_batch, feature_configs_java)

    tf.logging.info("finished java fg parsing...")
    tf.logging.info("tf fg...")
    fc_generator = FeatureColumnGenerator(feature_configs_tf)
    tf.logging.info("finished tf fg...")
    ########################################################
    params = {name: value for name, value in FLAGS.__flags.items()}
    print("print params...")
    for key in params:
        print("params {}: {}".format(key, params[key]))
    return features, label_dict, fc_generator, params


def parser(batch, feature_configs):
    columns = batch.get_next()
    key, feature, label, _ = columns
    # shape must be rank 1
    feature = tf.reshape(feature, [-1, 1])
    feature = tf.squeeze(feature, axis=1)
    features = rtp_fg.parse_genreated_fg(feature_configs, feature)
    label_dict = {}
    label_dict['click'] = label
    # label_dict['pay'] = label_pay
    return features, label_dict


def input_fn(files, batch_size, mode, is_sequence_train, slice_id, slice_count):
    tf.logging.info("slice_count:{}, slice_id:{}".format(slice_count, slice_id))
    if mode == 'train':
        if is_sequence_train:
            # sequence train
            dataset = tf.data.TableRecordDataset(files, [[' ']] * table_col_num, slice_id=slice_id,
                                                 slice_count=slice_count).batch(batch_size)
        else:
            # global train
            dataset = tf.data.TableRecordDataset(files, [[' ']] * table_col_num, slice_id=slice_id,
                                                 slice_count=slice_count).shuffle(
                buffer_size=200 * batch_size).repeat().batch(batch_size)
    elif mode == 'dev':
        dataset = tf.data.TableRecordDataset(files, [[' ']] * table_col_num, slice_id=slice_id,
                                             slice_count=slice_count).repeat().batch(batch_size)
    return dataset


def input_fn_normal(files, batch_size, mode):
    if mode == 'train':
        dataset = tf.data.TableRecordDataset(files, [[' ']] * table_col_num).shuffle(
            buffer_size=200 * batch_size).repeat().batch(batch_size)
    elif mode == 'dev':
        dataset = tf.data.TableRecordDataset(files, [[' ']] * table_col_num).repeat().batch(batch_size)
    return dataset


def transform_fg(dic_0):
    remove_list = ["is_wide", "value_type", "hash_bucket_size", "embed_size", "shared", "shared_matrix_name",
                   "normalizer", "is_list"]
    for dic_1 in dic_0['features']:
        if "sequence_name" in dic_1:
            for dic_2 in dic_1['features']:
                for remove_key in remove_list:
                    if remove_key in dic_2:
                        del dic_2[remove_key]
        else:
            for remove_key in remove_list:
                if remove_key in dic_1:
                    del dic_1[remove_key]
    return dic_0

