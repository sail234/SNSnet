# -*- coding: utf-8 -*-
import tensorflow as tf
from tools import *

linear_parent_scope = "linear"
dnn_parent_scope = "dnn"



def model_block(features, label_dict, fc_generator, is_training, keep_prob, params):
    # parse params
    black_list = params['black_list'] if 'black_list' in params else ""
    num_heads = params['num_heads'] if 'num_heads' in params else 4
    linear_key_dim = params['linear_key_dim'] if 'linear_key_dim' in params else 40
    linear_value_dim = params['linear_value_dim'] if 'linear_value_dim' in params else 40
    output_dim = params['output_dim'] if 'output_dim' in params else 40
    hidden_dim = params['hidden_dim'] if 'hidden_dim' in params else 64
    num_layer = params['num_layer'] if 'num_layer' in params else 3
    ########################################################
    # dnn
    tf.logging.info("building features...")
    outputs_dict = fc_generator.get_output_dict(features, black_list)

    tf.logging.info("build user fea")
    user_fea_names = ['is_user_f1','is_user_f2','is_user_f4','is_user_f5','is_user_f6','is_user_f7',
                    'is_user_f8','is_user_f9','is_user_f10','is_user_f11','is_user_f12','is_user_f13',
                    'is_user_f14','is_user_f15','is_user_f16','is_user_f17','is_user_f18','is_user_f19',
                    'is_user_f20','is_user_f21','is_user_f22','is_user_f23','is_user_f24','is_user_f25',
                    'is_user_f26','is_user_f27','is_user_f28','is_user_f29','is_user_f30','is_user_f31',
                    'is_user_f32','is_user_f33','is_user_f34','is_user_f35','is_user_f36','is_user_f37',
                    'is_user_f38','is_user_f39','is_user_f40','is_user_f41','is_user_f42','is_user_f43',
                    'is_user_f44','is_user_f45','is_user_f46','is_user_f47','is_user_f48']
    user_feats_set = []
    for key in outputs_dict:
        if key in user_fea_names:
            tf.logging.info(key)
            user_feats_set.append((key, outputs_dict[key]))
    user_feats_set = [feat for _, feat in sorted(user_feats_set, key=lambda x: x[0])]

    tf.logging.info("build item fea")
    item_fea_names = ['is_item_f49', 'is_item_f50', 'is_item_f51', 'is_item_f52', 'is_item_f53', 'is_item_f54', 'is_item_f55',
                    'is_item_f56', 'is_item_f57', 'is_item_f58', 'is_item_f59', 'is_item_f60', 'is_item_f61',
                    'is_item_f62', 'is_item_f63', 'is_item_f64', 'is_item_f65', 'is_item_f66', 'is_item_f67',
                    'is_item_f68', 'is_item_f69', 'is_item_f70', 'is_item_f71']
    item_fea_set = []
    for key in outputs_dict:
        if key in item_fea_names:
            tf.logging.info(key)
            item_fea_set.append((key, outputs_dict[key]))
    item_fea_set = [feat for _, feat in sorted(item_fea_set, key=lambda x: x[0])]


    # clicks
    shared_click_city_id = outputs_dict["shared_click_city_id_v1"]
    shared_click_city_id = tf.concat([tf.expand_dims(id, axis=1) for id in shared_click_city_id], axis=1)

    shared_click_cate_id = outputs_dict["shared_click_cate_id_v1"]
    shared_click_cate_id = tf.concat([tf.expand_dims(id, axis=1) for id in shared_click_cate_id], axis=1)

    shared_click_type_id = outputs_dict["shared_click_type_id_v1"]
    shared_click_type_id = tf.concat([tf.expand_dims(id, axis=1) for id in shared_click_type_id], axis=1)

    shared_click_item_id = outputs_dict["shared_click_item_id_v1"]
    shared_click_item_id = tf.concat([tf.expand_dims(id, axis=1) for id in shared_click_item_id], axis=1)

    clicks_set_clicks_set_mask = outputs_dict["user_recently_clicks_list_v2_clicks_set_mask"]
    clicks_set_clicks_set_mask = tf.concat(clicks_set_clicks_set_mask, axis=1)

    # user_state
    shared_user_lfcy_id = outputs_dict["shared_user_lfcy_one"]
    shared_user_lfcy_id = tf.concat([tf.expand_dims(id, axis=1) for id in shared_user_lfcy_id], axis=1)

    clicks_set_click_user_lfcy_session = outputs_dict["user_recently_clicks_list_v2_click_user_lfcy_session"]
    clicks_set_click_user_lfcy_session = tf.concat(clicks_set_click_user_lfcy_session, axis=1)



    #session level
    shared_user_lfcy_id_dup = outputs_dict["shared_user_lfcy_seq"]
    shared_user_lfcy_id_dup = tf.concat([tf.expand_dims(id, axis=1) for id in shared_user_lfcy_id_dup], axis=1)

    user_lfcy_session_seq = outputs_dict["user_state_seq_dup_user_lfcy_session_seq"]
    user_lfcy_session_seq = tf.concat(user_lfcy_session_seq, axis=1)

    user_state_seq_mask = outputs_dict["user_state_seq_dup_user_state_seq_mask"]
    user_state_seq_mask = tf.concat(user_state_seq_mask, axis=1)

    print("user_state_seq_mask", user_state_seq_mask)

    user_lfcy_session_seq = tf.expand_dims(user_lfcy_session_seq, axis=1)
    user_lfcy_session_seq = tf.tile(user_lfcy_session_seq, [1, 30, 1])
    user_lfcy_session_seq = tf.transpose(user_lfcy_session_seq, [0, 2, 1])
    print("user_lfcy_session_seq", user_lfcy_session_seq)

    clicks_set_click_user_lfcy_session = tf.expand_dims(clicks_set_click_user_lfcy_session, axis=1)
    clicks_set_click_user_lfcy_session = tf.tile(clicks_set_click_user_lfcy_session, [1, 5, 1])

    zeros_bhv = tf.zeros_like(clicks_set_click_user_lfcy_session)
    clicks_set_lfcy_mask = tf.where(tf.equal(clicks_set_click_user_lfcy_session, user_lfcy_session_seq), zeros_bhv + 1, zeros_bhv)
    print("clicks_set_lfcy_mask", clicks_set_lfcy_mask)
    clicks_set_lfcy_mask = tf.expand_dims(clicks_set_lfcy_mask, axis=3)
    clicks_set_lfcy_mask = tf.tile(clicks_set_lfcy_mask, [1, 1, 1, 8])
    print("clicks_set_lfcy_mask", clicks_set_lfcy_mask)

    #double level attention
    shared_click_city_id_session = tf.expand_dims(shared_click_city_id, axis=1)
    shared_click_city_id_session = tf.tile(shared_click_city_id_session, [1, 5, 1, 1])
    print("shared_click_city_id_session", shared_click_city_id_session)
    shared_click_city_id_session = tf.reduce_mean(clicks_set_lfcy_mask * shared_click_city_id_session, axis = 2)

    shared_click_cate_id_session = tf.expand_dims(shared_click_cate_id, axis=1)
    shared_click_cate_id_session = tf.tile(shared_click_cate_id_session, [1, 5, 1, 1])
    print("shared_click_city_id_session", shared_click_cate_id_session)
    shared_click_cate_id_session = tf.reduce_mean(clicks_set_lfcy_mask * shared_click_cate_id_session, axis = 2)

    shared_click_type_id_session = tf.expand_dims(shared_click_type_id, axis=1)
    shared_click_type_id_session = tf.tile(shared_click_type_id_session, [1, 5, 1, 1])
    print("shared_click_type_id_session", shared_click_type_id_session)
    shared_click_type_id_session = tf.reduce_mean(clicks_set_lfcy_mask * shared_click_type_id_session, axis = 2)

    shared_click_item_id_session = tf.expand_dims(shared_click_item_id, axis=1)
    shared_click_item_id_session = tf.tile(shared_click_item_id_session, [1, 5, 1, 1])
    print("shared_click_item_id_session", shared_click_item_id_session)
    shared_click_item_id_session = tf.reduce_mean(clicks_set_lfcy_mask * shared_click_item_id_session, axis = 2)


    activation_fn = tf.nn.relu

    user_state = outputs_dict["is_user_f3"]
    lbs_city_id = outputs_dict['is_user_f1']
    geohash5 = outputs_dict['is_user_f2']

    user_lfcy_one = outputs_dict['next_state']
    user_lfcy_one = tf.cast(user_lfcy_one, tf.int32)
    user_lfcy_one = tf.squeeze(user_lfcy_one)


    label_1 = outputs_dict['label_1']
    # label_1 = tf.cast(label_1, tf.int32)
    # label_1 = tf.squeeze(label_1)

    label_2 = outputs_dict['label_2']
    # label_2 = tf.cast(label_2, tf.int32)
    # label_2 = tf.squeeze(label_2)

    label_3 = outputs_dict['label_3']
    # label_3 = tf.cast(label_3, tf.int32)
    # label_3 = tf.squeeze(label_3)

    label_4 = outputs_dict['label_4']
    # label_4 = tf.cast(label_4, tf.int32)
    # label_4 = tf.squeeze(label_4)

    label_mask_1 = outputs_dict['label_mask_1']
    # label_mask_1 = tf.cast(label_mask_1, tf.int32)
    # label_mask_1 = tf.squeeze(label_mask_1)

    label_mask_2 = outputs_dict['label_mask_2']
    # label_mask_2 = tf.cast(label_mask_2, tf.int32)
    # label_mask_2 = tf.squeeze(label_mask_2)

    label_mask_3 = outputs_dict['label_mask_3']
    # label_mask_3 = tf.cast(label_mask_3, tf.int32)
    # label_mask_3 = tf.squeeze(label_mask_3)

    label_mask_4 = outputs_dict['label_mask_4']



    city_id = outputs_dict["is_user_f1"]
    with tf.variable_scope("clicks"):
        clicks_features = tf.concat(
            [shared_click_item_id, shared_click_city_id, shared_click_cate_id, shared_click_type_id, shared_user_lfcy_id], axis=2)

        clicks_trans_block = SelfAttentionPooling(
            num_heads=num_heads,
            key_mask=clicks_set_clicks_set_mask,
            query_mask=clicks_set_clicks_set_mask,
            length=30,
            linear_key_dim=linear_key_dim,
            linear_value_dim=linear_value_dim,
            output_dim=output_dim,
            hidden_dim=hidden_dim,
            num_layer=num_layer,
            keep_prob=keep_prob
        )
        clicks_trans_output = clicks_trans_block.build(clicks_features, reuse=False,
                                                       scope='clicks_trans')  # (batch_size, 30, output_dim)

        clicks_pool_res = tf.reduce_sum(clicks_trans_output, axis=1)
        print("clicks_pool_res:", clicks_pool_res)


    with tf.variable_scope("lfcy_session"):
        lfcy_session_features = tf.concat(
            [shared_click_city_id_session, shared_click_cate_id_session, shared_click_type_id_session, shared_click_item_id_session, shared_user_lfcy_id_dup], axis=2)

        lfcy_session_trans_block = SelfAttentionPooling(
            num_heads=num_heads,
            key_mask=user_state_seq_mask,
            query_mask=user_state_seq_mask,
            length=5,
            linear_key_dim=linear_key_dim,
            linear_value_dim=linear_value_dim,
            output_dim=output_dim,
            hidden_dim=hidden_dim,
            num_layer=num_layer,
            keep_prob=keep_prob
        )
        lfcy_session_trans_output = lfcy_session_trans_block.build(lfcy_session_features, reuse=False,
                                                       scope='lfcy_session_features')  # (batch_size, 30, output_dim)

        lfcy_session_pool_res = tf.reduce_sum(lfcy_session_trans_output, axis=1)
        print("lfcy_session_pool_res:", lfcy_session_pool_res)


    with tf.variable_scope('user_state_pre'):

        user_state_input = tf.concat([clicks_pool_res, lfcy_session_pool_res, user_state, city_id], axis=1)

        user_state_input = layers.fully_connected(user_state_input, 8, activation_fn=None, scope='ffn_1',
                                          variables_collections=[dnn_parent_scope])

        #user_state_mind = user_state_input

        user_state_input = layers.batch_norm(user_state_input, is_training=is_training, activation_fn=activation_fn,
                                            variables_collections=[dnn_parent_scope])

        user_state_pre = layers.fully_connected(user_state_input, 4, activation_fn=None, scope='ffn_2',
                                                  variables_collections=[dnn_parent_scope])

    with tf.variable_scope('logit'):

        # item
        item_fea_input = item_fea_set
        item_fea_input = tf.concat(item_fea_input, axis=1)
        item_fea = layers.batch_norm(item_fea_input, is_training=is_training, activation_fn=None, variables_collections=[dnn_parent_scope])
        item_fea = layers.fully_connected(item_fea, 128, activation_fn=None, scope='ffn_11', variables_collections=[dnn_parent_scope])
        item_fea = layers.batch_norm(item_fea, is_training=is_training, activation_fn=None, variables_collections=[dnn_parent_scope])
        item_fea = layers.fully_connected(item_fea, 32, activation_fn=None, scope='ffn_12', variables_collections=[dnn_parent_scope])

        # user group
        user_input = user_feats_set
        user_input = tf.concat(user_input, axis=1)
        user_input = tf.reshape(user_input, [-1, 47, 8])
        query = user_state_pre
        print "query.shape:", query.shape
        user_attribute_fea = attention_padding_v1(user_input, query, None, reuse=False, vec_dims=8, seqlens=47, query_dims=4, scope='pool_attention')
        print "user_attribute_fea.shape:", user_attribute_fea.shape


        with tf.variable_scope('logit_1'):
            user_group_fea = tf.concat([user_attribute_fea] + [clicks_pool_res] + user_feats_set, axis=1)
            user_group_fea = layers.batch_norm(user_group_fea, is_training=is_training, activation_fn=activation_fn,
                                               variables_collections=[dnn_parent_scope])
            user_group_fea = layers.fully_connected(user_group_fea, 128, activation_fn=None, scope='ffn_21',
                                                    variables_collections=[dnn_parent_scope])
            user_group_fea = layers.batch_norm(user_group_fea, is_training=is_training, activation_fn=activation_fn,
                                               variables_collections=[dnn_parent_scope])
            user_group_fea_1 = layers.fully_connected(user_group_fea, 32, activation_fn=None, scope='ffn_22',
                                                    variables_collections=[dnn_parent_scope])

        with tf.variable_scope('logit_2'):
            user_group_fea = tf.concat([user_attribute_fea] + [clicks_pool_res] + user_feats_set, axis=1)
            user_group_fea = layers.batch_norm(user_group_fea, is_training=is_training, activation_fn=activation_fn,
                                               variables_collections=[dnn_parent_scope])
            user_group_fea = layers.fully_connected(user_group_fea, 128, activation_fn=None, scope='ffn_21',
                                                    variables_collections=[dnn_parent_scope])
            user_group_fea = layers.batch_norm(user_group_fea, is_training=is_training, activation_fn=activation_fn,
                                               variables_collections=[dnn_parent_scope])
            user_group_fea_2 = layers.fully_connected(user_group_fea, 32, activation_fn=None, scope='ffn_22',
                                                    variables_collections=[dnn_parent_scope])

        with tf.variable_scope('logit_3'):
            user_group_fea = tf.concat([user_attribute_fea] + [clicks_pool_res] + user_feats_set, axis=1)
            user_group_fea = layers.batch_norm(user_group_fea, is_training=is_training, activation_fn=activation_fn,
                                               variables_collections=[dnn_parent_scope])
            user_group_fea = layers.fully_connected(user_group_fea, 128, activation_fn=None, scope='ffn_21',
                                                    variables_collections=[dnn_parent_scope])
            user_group_fea = layers.batch_norm(user_group_fea, is_training=is_training, activation_fn=activation_fn,
                                               variables_collections=[dnn_parent_scope])
            user_group_fea_3 = layers.fully_connected(user_group_fea, 32, activation_fn=None, scope='ffn_22',
                                                    variables_collections=[dnn_parent_scope])

        with tf.variable_scope('logit_4'):
            user_group_fea = tf.concat([user_attribute_fea] + [clicks_pool_res] + user_feats_set, axis=1)
            user_group_fea = layers.batch_norm(user_group_fea, is_training=is_training, activation_fn=activation_fn,
                                               variables_collections=[dnn_parent_scope])
            user_group_fea = layers.fully_connected(user_group_fea, 128, activation_fn=None, scope='ffn_21',
                                                    variables_collections=[dnn_parent_scope])
            user_group_fea = layers.batch_norm(user_group_fea, is_training=is_training, activation_fn=activation_fn,
                                               variables_collections=[dnn_parent_scope])
            user_group_fea_4 = layers.fully_connected(user_group_fea, 32, activation_fn=None, scope='ffn_22',
                                                    variables_collections=[dnn_parent_scope])

        with tf.variable_scope('expert_gate_logit'):

            gate_output = tf.nn.softmax(user_state_pre)

            # expert_gate_output = tf.reduce_mean(gate_output, axis=0)
            expert_gate_output = gate_output

            print("expert_gate_output", gate_output)

            expert_gate_output = tf.expand_dims(expert_gate_output, axis = 2)

            print("expert_gate_output", expert_gate_output)

            expert_gate_output = tf.tile(expert_gate_output, multiples=[1, 1, 32])

            print("expert_gate_output", expert_gate_output)

            expert_gate_output = tf.transpose(expert_gate_output, [0, 2, 1])

            expert_gate_output = tf.reshape(expert_gate_output, [-1, 128])

            print("expert_gate_output", expert_gate_output)


        output_list = [user_group_fea_1] + [user_group_fea_2] + [user_group_fea_3] + [user_group_fea_4]
        output_list = tf.concat(output_list, axis=1)


        print("output_list:", output_list)

        output_list = tf.multiply(output_list, output_list)
        output_list = tf.reshape(output_list, [-1, 4, 32])

        print ("output_list:", output_list)


        # user group embed 和 item embed 点击
        with tf.variable_scope('final_pre'):
            user_group_fea = tf.reduce_sum(output_list, axis=1)
            user_group_fea_noraml = tf.sqrt(tf.reduce_sum(tf.square(user_group_fea),1, keep_dims=True))
            user_group_fea = user_group_fea/user_group_fea_noraml
            print "user_group_fea.shape:", user_group_fea.shape
            item_fea_noraml_f = tf.sqrt(tf.reduce_sum(tf.square(item_fea),1, keep_dims=True))
            item_fea_f = item_fea/item_fea_noraml_f
            print "item_fea.shape:", item_fea.shape
            score = tf.keras.layers.Dot(1)([user_group_fea, item_fea_f])
            logit = score * 10


        with tf.variable_scope('final_1'):
            user_group_fea = user_group_fea_1
            user_group_fea_noraml = tf.sqrt(tf.reduce_sum(tf.square(user_group_fea),1, keep_dims=True))
            user_group_fea = user_group_fea/user_group_fea_noraml
            print "user_group_fea.shape:", user_group_fea.shape
            item_fea_noraml_0 = tf.sqrt(tf.reduce_sum(tf.square(item_fea), 1, keep_dims=True))
            item_fea_0 = item_fea / item_fea_noraml_0
            print "item_fea.shape:", item_fea_0.shape
            score = tf.keras.layers.Dot(1)([user_group_fea, item_fea_0])
            logit_1 = score * 10

        with tf.variable_scope('final_2'):
            user_group_fea = user_group_fea_2
            user_group_fea_noraml = tf.sqrt(tf.reduce_sum(tf.square(user_group_fea),1, keep_dims=True))
            user_group_fea = user_group_fea/user_group_fea_noraml
            print "user_group_fea.shape:", user_group_fea.shape
            item_fea_noraml_0 = tf.sqrt(tf.reduce_sum(tf.square(item_fea), 1, keep_dims=True))
            item_fea_0 = item_fea / item_fea_noraml_0
            print "item_fea.shape:", item_fea_0.shape
            score = tf.keras.layers.Dot(1)([user_group_fea, item_fea_0])
            logit_2 = score * 10

        with tf.variable_scope('final_3'):
            user_group_fea = user_group_fea_3
            user_group_fea_noraml = tf.sqrt(tf.reduce_sum(tf.square(user_group_fea),1, keep_dims=True))
            user_group_fea = user_group_fea/user_group_fea_noraml
            print "user_group_fea.shape:", user_group_fea.shape
            item_fea_noraml_0 = tf.sqrt(tf.reduce_sum(tf.square(item_fea), 1, keep_dims=True))
            item_fea_0 = item_fea / item_fea_noraml_0
            print "item_fea.shape:", item_fea_0.shape
            score = tf.keras.layers.Dot(1)([user_group_fea, item_fea_0])
            logit_3 = score * 10

        with tf.variable_scope('final_4'):
            user_group_fea = user_group_fea_4
            user_group_fea_noraml = tf.sqrt(tf.reduce_sum(tf.square(user_group_fea),1, keep_dims=True))
            user_group_fea = user_group_fea/user_group_fea_noraml
            print "user_group_fea.shape:", user_group_fea.shape
            item_fea_noraml_0 = tf.sqrt(tf.reduce_sum(tf.square(item_fea), 1, keep_dims=True))
            item_fea_0 = item_fea / item_fea_noraml_0
            print "item_fea.shape:", item_fea_0.shape
            score = tf.keras.layers.Dot(1)([user_group_fea, item_fea_0])
            logit_4 = score * 10



    logit_dict = {}
    logit_dict['ctr'] = logit
    logit_dict['ctr_1'] = logit_1
    logit_dict['ctr_2'] = logit_2
    logit_dict['ctr_3'] = logit_3
    logit_dict['ctr_4'] = logit_4
    logit_dict['user_pre'] = user_state_pre

    label_click = label_dict['click']
    label_click = tf.cast(tf.equal(label_click, '1'), tf.float32)
    label_click = tf.reshape(label_click, [-1, 1])
    label_dict['click'] = label_click
    label_dict['user_label'] = user_lfcy_one
    label_dict['label_1'] = label_1
    label_dict['label_2'] = label_2
    label_dict['label_3'] = label_3
    label_dict['label_4'] = label_4

    label_dict['label_mask_1'] = label_mask_1
    label_dict['label_mask_2'] = label_mask_2
    label_dict['label_mask_3'] = label_mask_3
    label_dict['label_mask_4'] = label_mask_4



    return logit_dict, label_dict, user_group_fea, item_fea_f, features['is_user_f0'], features['is_user_f3'], features['is_user_f2'], features['is_item_f49']


