# -*- coding: utf-8 -*-
import tensorflow as tf
from tensorflow.contrib.layers.python.layers import optimizers
from tensorflow.python.ops import control_flow_ops
from tensorflow.python.ops import state_ops
from tensorflow.python.framework import ops

linear_parent_scope = "linear"
dnn_parent_scope = "dnn"


def make_training_op(training_loss, global_step, is_sequence_train):
    _DNN_LEARNING_RATE = 0.001
    _LINEAR_LEARNING_RATE = 0.005
    _GRADIENT_CLIP_NORM = 100.0

    warm_up_learning_rate = 0.0001
    warm_up_step = 50000
    init_learning_rate = 0.001
    decay_steps = 10000
    decay_rate = 0.96
    learning_rate = tf.train.smooth_exponential_decay(warm_up_learning_rate,
                                                      warm_up_step,
                                                      init_learning_rate,
                                                      global_step,
                                                      decay_steps,
                                                      decay_rate)

    with ops.control_dependencies(tf.get_collection(tf.GraphKeys.UPDATE_OPS)):
        train_ops = []
        # linear_optimizer = tf.train.FtrlOptimizer(
        #     learning_rate=_LINEAR_LEARNING_RATE,
        #     learning_rate_power=-0.5,
        #     initial_accumulator_value=1.0,
        #     l1_regularization_strength=0.1,
        #     l2_regularization_strength=0.01
        # )
        if is_sequence_train:
            dnn_optimizer = tf.train.AdamOptimizer(_DNN_LEARNING_RATE)
        else:
            dnn_optimizer = tf.train.AdamOptimizer(learning_rate)
        train_ops.append(
            optimizers.optimize_loss(
                loss=training_loss,
                global_step=global_step,
                learning_rate=_DNN_LEARNING_RATE,
                optimizer=dnn_optimizer,
                variables=ops.get_collection(dnn_parent_scope),
                name=dnn_parent_scope,
                clip_gradients=None,
                increment_global_step=None))
        tf.logging.info(
            "optimizer scope {} variables: {}".format(dnn_parent_scope, ops.get_collection(dnn_parent_scope)))
        train_op = control_flow_ops.group(*train_ops)
        with ops.control_dependencies([train_op]):
            with ops.colocate_with(global_step):
                return state_ops.assign_add(global_step, 1).op
