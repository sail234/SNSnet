# -*- coding: utf-8 -*-
import os
from model_fn import model_block
from tools import *
import time
from collections import defaultdict

# -----------------------------------------------------------------------------------------------------------
tf.logging.set_verbosity(tf.logging.INFO)
FLAGS = None
linear_parent_scope = "linear"
dnn_parent_scope = "dnn"


# -----------------------------------------------------------------------------------------------------------

def vec_model_fn(data_batch, global_step):
    features, label_dict, fc_generator, params = parse_fg(data_batch, FLAGS)
    logit_dict, label_dict, user_group_embed, item_embed, user_id, state, geohash5, item_id = model_block(features, label_dict,
                                                                                         fc_generator,
                                                                                         FLAGS.is_training,
                                                                                         FLAGS.keep_prob, params)
    item_id = tf.sparse_tensor_to_dense(item_id, "unknown")

    return user_group_embed, item_embed, None, item_id


def convert_presult_to_list(pred_result, fkeys):
    pred_result_list = [[] for i in range(len(fkeys))]
    for step, prob in enumerate(pred_result):
        print "convert step: {}".format(step + 1)
        for ind, fkey in enumerate(fkeys):
            key = fkey[0]
            if key in ('item_vec'):
                embed = ",".join(["%.8f" % pt if np.abs(pt) >= 0.00000001 else '0.0' for pt in prob[ind]])
                pred_result_list[ind].append(embed)
            else:
                pred_result_list[ind].append(prob[ind])

    return pred_result_list


def vec_out(FLAGS_):
    global FLAGS
    FLAGS = FLAGS_

    model_dir = FLAGS.model_dir
    batch_size = FLAGS.batch_size
    checkpointDir = FLAGS.checkpointDir
    buckets = FLAGS.buckets
    model_dir = os.path.join(checkpointDir, model_dir)
    handle = tf.placeholder(tf.string, shape=[])
    print("buckets:{} checkpointDir:{}".format(buckets, model_dir))
    # -----------------------------------------------------------------------------------------------
    tf.logging.info("loading input...")
    dev_file = FLAGS.dev_tables.split(',')
    dev_dataset = input_fn_normal(dev_file, batch_size, 'dev')
    dev_iterator = dev_dataset.make_one_shot_iterator()
    tf.logging.info("finished loading input...")
    # -----------------------------------------------------------------------------------------------
    user_group_embed, item_embed, _, item_id = vec_model_fn(dev_iterator, None)
    # -----------------------------------------------------------------------------------------------
    sess_config = tf.ConfigProto(allow_soft_placement=True,
                                 log_device_placement=False)

    saver = tf.train.Saver()
    with tf.Session(config=sess_config) as sess:
        sess.run(tf.global_variables_initializer())
        train_handle = sess.run(dev_iterator.string_handle())

        ckpt_state = tf.train.get_checkpoint_state(model_dir)
        tf.logging.info('output from checkpoint: {}'.format(ckpt_state.model_checkpoint_path))
        saver.restore(sess, ckpt_state.model_checkpoint_path)
        dev_num_batches = FLAGS.dev_total // FLAGS.batch_size

        gen_result = []
        for batch_ in range(1, dev_num_batches + 1):
            try:
                id_, vec_ = sess.run([item_id, item_embed], feed_dict={handle: train_handle})
                print 'itemid   ', id_, "    vec:  ", vec_
                gen_result.extend(zip(id_, vec_))
            except Exception, e:
                tf.logging.info("catch a exception: %s" % e.message)
                break

    tf.logging.info("convert item to tensor...")
    result_dict = [('item_id', tf.string), ('item_vec', tf.string)]
    pred_result_list = convert_presult_to_list(gen_result, result_dict)

    result_table = FLAGS.outputs
    id_list = np.array(pred_result_list[0]).reshape(len(pred_result_list[0]), 1)
    vecter_list = np.array(pred_result_list[1]).reshape(len(pred_result_list[1]), 1)
    id_placeholder = tf.placeholder(tf.string, shape=[len(id_list), 1])
    vecter_placeholder = tf.placeholder(tf.string, shape=[len(vecter_list), 1])
    tf.logging.info("convert pred_result to tensor success, and write in table begin...")
    writer = tf.TableRecordWriter(result_table)
    write_to_table = writer.write(range(2), [id_placeholder, vecter_placeholder])
    close_table = writer.close()
    with tf.Session() as sess:
        sess.run(tf.global_variables_initializer())
        sess.run(tf.local_variables_initializer())
        sess.run(write_to_table, feed_dict={id_placeholder: id_list, vecter_placeholder: vecter_list})
        sess.run(close_table)
        tf.logging.info("write in table success!")
