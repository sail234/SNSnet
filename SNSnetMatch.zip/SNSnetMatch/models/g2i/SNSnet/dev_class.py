# -*- coding: utf-8 -*-
import os
from model_fn import model_block
from tools import *
import time
from collections import defaultdict

# -----------------------------------------------------------------------------------------------------------
tf.logging.set_verbosity(tf.logging.INFO)
FLAGS = None
linear_parent_scope = "linear"
dnn_parent_scope = "dnn"


# -----------------------------------------------------------------------------------------------------------
def dev_loss_and_metrics_step(logit_dict, label_dict, scope):
    with tf.variable_scope(scope):
        label = label_dict['click']
        logit = logit_dict['ctr']
        with tf.variable_scope('predict'):
            # for rank service 2.0
            p_logit = tf.sigmoid(logit)
            predict_score = tf.identity(p_logit, name="rank_predict")


        print "predict_score: ", predict_score

        with tf.name_scope("metrics"):
            prepossum = tf.reduce_sum(label * predict_score)
            prenegsum = tf.reduce_sum((1.0 - label) * predict_score)
            gtpossum = tf.reduce_sum(label)
            gtnegsum = tf.reduce_sum(tf.cast(tf.equal(label, 0.0), tf.float32))
            mae = tf.reduce_sum(tf.abs(predict_score - label))
            mse = tf.reduce_sum((predict_score - label) * (predict_score - label))

            metrics = [prepossum, prenegsum, gtpossum, gtnegsum, mae, mse, label, predict_score]

        with tf.name_scope('loss'):
            loss = tf.nn.sigmoid_cross_entropy_with_logits(labels=label, logits=logit, name='sigmoid_cross_entropy')
            loss = tf.reduce_mean(loss)
        return loss, metrics


def dev_model_fn(data_batch, global_step):
    features, label_dict, fc_generator, params = parse_fg(data_batch, FLAGS)
    logit_dict, label_dict, user_group_embed, item_embed, user_id, state, geohash5, item_id = model_block(features, label_dict, fc_generator, FLAGS.is_training, FLAGS.keep_prob, params)
    loss, metrics = dev_loss_and_metrics_step(logit_dict, label_dict, "loss_and_metrics")

    item_id = tf.sparse_tensor_to_dense(item_id, "unknown")
    user_id = tf.sparse_tensor_to_dense(user_id, "unknown")
    print " user_id ", user_id, " user_group_embed ", user_group_embed, " item_id ", item_id, " item_embed ", item_embed
    return loss, None, metrics, user_group_embed, user_id, item_embed, item_id 



def dev_step(loss, metrics, step, sess, step_name, user_group_embed, user_id, item_embed, item_id):
    prepossum, prenegsum, gtpossum, gtnegsum, mae, mse, label, predict_score = metrics
    preds = []
    labels = []
    prepossum_list = []
    prenegsum_list = []
    gtpossum_list = []
    gtnegsum_list = []
    losssum_list = []
    maesum_list = []
    msesum_list = []

    triplet_loss_list = []
    fraction_postive_triplets_list =[]

    dic_preds_pv = defaultdict(list)
    dic_labels_pv = defaultdict(list)

    dic_preds_u = defaultdict(list)
    dic_labels_u = defaultdict(list)

    dic_preds_uj = defaultdict(list)
    dic_labels_uj = defaultdict(list)
    dic_items_uj = defaultdict(list)

    dev_num_batches = FLAGS.dev_total // FLAGS.batch_size + 1
    for batch_ in range(1, dev_num_batches + 1):
        tf.logging.info("batch: {}, at {}".format(batch_, step))
        prepossum_, prenegsum_, gtpossum_, gtnegsum_, mae_, mse_, clk_val, p_logit_val, loss_, user_group_embed_, user_id_, item_embed_, item_id_ = sess.run(
            [prepossum, prenegsum, gtpossum, gtnegsum, mae, mse, label, predict_score, loss, user_group_embed, user_id, item_embed, item_id])

        for _clk_val, _p_logit_val in zip(clk_val, p_logit_val):
            _clk = int(_clk_val[0])
            _p_logit = float(_p_logit_val[0])

            preds.append(_p_logit)
            labels.append(_clk)

        prepossum_list.append(prepossum_)
        prenegsum_list.append(prenegsum_)
        gtpossum_list.append(gtpossum_)
        gtnegsum_list.append(gtnegsum_)
        losssum_list.append(loss_)
        maesum_list.append(mae_)
        msesum_list.append(mse_)


    prepossum_val = np.sum(prepossum_list)
    prenegsum_val = np.sum(prenegsum_list)
    gtpossum_val = np.sum(gtpossum_list)
    gtnegsum_val = np.sum(gtnegsum_list)
    losssum_val = np.sum(losssum_list)
    maesum_val = np.sum(maesum_list)
    msesum_val = np.sum(msesum_list)


    ctr = gtpossum_val / (gtpossum_val + gtnegsum_val + 1e-8)
    prectr = (prepossum_val + prenegsum_val) / (gtpossum_val + gtnegsum_val + 1e-8)
    pcopc = (prepossum_val + prenegsum_val) / (gtpossum_val + 1e-8)
    pos_mean = prepossum_val / (gtpossum_val + 1e-8)
    neg_mean = prenegsum_val / (gtnegsum_val + 1e-8)
    auc = roc_auc_score(labels, preds)

    loss_mean = losssum_val / (gtpossum_val + gtnegsum_val + 1e-8)
    mae_mean = maesum_val / (gtpossum_val + gtnegsum_val + 1e-8)
    mse_mean = msesum_val / (gtpossum_val + gtnegsum_val + 1e-8)


    print(
        "pos_mean: {} neg_mean: {} pcopc: {} ctr: {} prectr: {} mae: {} mse: {} auc: {}, loss: {}, at {}".format(
            pos_mean, neg_mean, pcopc, ctr, prectr, mae_mean, mse_mean, auc, loss_mean, step))



def convert_presult_to_list(pred_result, fkeys):
    pred_result_list = [[] for i in range(len(fkeys))]
    for step, prob in enumerate(pred_result):
        tf.logging.info("convert step: {}".format(step + 1))
        for ind, fkey in enumerate(fkeys):
            key = fkey[0]
            if key in ('user_taobao_vec'):
                embed = ",".join(["%.8f" % pt if np.abs(pt) >= 0.00000001 else '0.0' for pt in prob[ind]])
                pred_result_list[ind].append(embed)
            else:
                pred_result_list[ind].append(prob[ind])
    return pred_result_list



def dev(FLAGS_):
    global FLAGS
    FLAGS = FLAGS_

    model_dir = FLAGS.model_dir
    batch_size = FLAGS.batch_size
    checkpointDir = FLAGS.checkpointDir
    buckets = FLAGS.buckets
    model_dir = os.path.join(checkpointDir, model_dir)
    print("buckets:{} checkpointDir:{}".format(buckets, model_dir))
    # -----------------------------------------------------------------------------------------------
    tf.logging.info("loading input...")
    dev_file = FLAGS.dev_tables.split(',')
    dev_dataset = input_fn_normal(dev_file, batch_size, 'dev')
    dev_iterator = dev_dataset.make_one_shot_iterator()
    tf.logging.info("finished loading input...")
    # -----------------------------------------------------------------------------------------------
    loss, _, metrics, user_group_embed, user_id, item_embed, item_id = dev_model_fn(dev_iterator, None)
    # -----------------------------------------------------------------------------------------------
    sess_config = tf.ConfigProto(allow_soft_placement=True,
                                 log_device_placement=False)

    saver = tf.train.Saver()
    with tf.Session(config=sess_config) as sess:
        step = -1
        time_before = time.time()
        model_test_index = 0
        while 1:
            if time.time() - time_before > 1800 * 3:
                print('no model update and eval finish...')
                break
            ckpt_state = tf.train.get_checkpoint_state(model_dir)
            if ckpt_state is None:
                continue

            allpaths =  ckpt_state.all_model_checkpoint_paths

            if model_test_index < len(allpaths):
                final_path = allpaths[model_test_index]
            else:
                final_path = allpaths[-1]
            now_step = int(final_path.split('-')[-1])
            if now_step > step:
                model_test_index += 1
                time_before = time.time()
                time.sleep(30)
                step = now_step
                print('test checkpoint: {}'.format(final_path))
                saver.restore(sess, final_path)
                dev_step(loss, metrics, step, sess, "dev_step", user_group_embed, user_id, item_embed, item_id)
